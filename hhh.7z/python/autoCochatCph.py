#!/usr/bin/python
#-*- coding:utf-8 -*-

from autoCochat import AutoCochat

if __name__ == '__main__':
    obj = AutoCochat("Test") 
    obj.test()

