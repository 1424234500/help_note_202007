import sys
from json import dump
def f():
    import os
f()
print sys.modules.keys()


