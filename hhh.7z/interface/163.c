网易云歌曲连接盗用

http://music.163.com/api/search/get/web?csrf_token=
post
{
   "hlpretag":"",
   "hlposttag=":"",
   "s":":"again",
   "type":1,
   "offset":0,
   "total":"true",
   "limit":10,
}
//    hlpretag=&hlposttag=&s=搜索歌曲名或歌手名&type=1&offset=0&total=true&limit=返回数据条数


外链转换id
http://link.hhtjim.com/163/464674029.mp3
{
	"result": {
		"songs": [
        {
			"id": 668479,
			"name": "again",
			"artists": [{
				"id": 18168,
				"name": "YUI",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			}],
			"album": {
				"id": 64498,
				"name": "again",
				"artist": {
					"id": 0,
					"name": "",
					"picUrl": null,
					"alias": [],
					"albumSize": 0,
					"picId": 0,
					"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
					"img1v1": 0,
					"trans": null
				},
				"publishTime": 1243958400000,
				"size": 4,
				"copyrightId": 5003,
				"status": 0,
				"picId": 829031767343340
			},
			"duration": 257776,
			"copyrightId": 663018,
			"status": 0,
			"alias": ["TV\xe3\x82\xa2\xe3\x83\x8b\xe3\x83\xa1\xe3\x80\x8e\xe9\x8b\xbc\xe3\x81\xae\xe9\x8c\xac\xe9\x87\x91\xe8\xa1\x93\xe5\xb8\xab FULLMETAL ALCHEMIST\xe3\x80\x8fOP"],
			"rtype": 0,
			"ftype": 0,
			"mvid": 0,
			"fee": 0,
			"rUrl": null,
			"alias": ["TV\xe3\x82\xa2\xe3\x83\x8b\xe3\x83\xa1\xe3\x80\x8e\xe9\x8b\xbc\xe3\x81\xae\xe9\x8c\xac\xe9\x87\x91\xe8\xa1\x93\xe5\xb8\xab FULLMETAL ALCHEMIST\xe3\x80\x8fOP"]
		},
		{
			"id": 524270871,
			"name": "Again (Alan Walker Remix)",
			"artists": [{
				"id": 12175271,
				"name": "Noah Cyrus",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			},
			{
				"id": 12107961,
				"name": "XXXTENTACION",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			},
			{
				"id": 1045123,
				"name": "Alan Walker",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			}],
			"album": {
				"id": 36901682,
				"name": "Again (Alan Walker Remix)",
				"artist": {
					"id": 0,
					"name": "",
					"picUrl": null,
					"alias": [],
					"albumSize": 0,
					"picId": 0,
					"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
					"img1v1": 0,
					"trans": null
				},
				"publishTime": 1513612800007,
				"size": 1,
				"copyrightId": 7001,
				"status": 3,
				"picId": 18338754440266431
			},
			"duration": 165226,
			"copyrightId": 7001,
			"status": 0,
			"alias": [],
			"rtype": 0,
			"ftype": 0,
			"mvid": 5780086,
			"fee": 8,
			"rUrl": null
		},
		{
			"id": 529661081,
			"name": "again",
			"artists": [{
				"id": 12062308,
				"name": "timmies",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			},
			{
				"id": 0,
				"name": "Shiloh",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			}],
			"album": {
				"id": 37240022,
				"name": "again",
				"artist": {
					"id": 0,
					"name": "",
					"picUrl": null,
					"alias": [],
					"albumSize": 0,
					"picId": 0,
					"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
					"img1v1": 0,
					"trans": null
				},
				"publishTime": 1514217600007,
				"size": 1,
				"copyrightId": 0,
				"status": 0,
				"picId": 109951163105350632
			},
			"duration": 156998,
			"copyrightId": 0,
			"status": 0,
			"alias": [],
			"rtype": 0,
			"ftype": 0,
			"mvid": 0,
			"fee": 0,
			"rUrl": null
		},
		{
			"id": 429460164,
			"name": "Again\xef\xbc\x88Cover \xe6\xa8\xaa\xe5\xb1\xb1\xe5\x85\x8b\xef\xbc\x89",
			"artists": [{
				"id": 12027267,
				"name": "\xe6\x80\xaa\xe7\x9b\x97V",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			}],
			"album": {
				"id": 34871085,
				"name": "\xe5\x9b\x9b\xe6\x9c\x88\xe6\x98\xaf\xe4\xbd\xa0\xe7\x9a\x84\xe8\xb0\x8e\xe8\xa8\x80\xe3\x80\x90\xe6\x9c\xa8\xe5\x90\x89\xe4\xbb\x96\xe5\x90\x88\xe5\xa5\x8f\xe3\x80\x91",
				"artist": {
					"id": 0,
					"name": "",
					"picUrl": null,
					"alias": [],
					"albumSize": 0,
					"picId": 0,
					"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
					"img1v1": 0,
					"trans": null
				},
				"publishTime": 1422720000000,
				"size": 2,
				"copyrightId": 0,
				"status": 1,
				"picId": 18198016951761326
			},
			"duration": 142971,
			"copyrightId": 0,
			"status": 0,
			"alias": [],
			"rtype": 0,
			"ftype": 0,
			"mvid": 0,
			"fee": 0,
			"rUrl": null
		},
		{
			"id": 668472,
			"name": "again (YUI Acoustic Version)",
			"artists": [{
				"id": 18168,
				"name": "YUI",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			}],
			"album": {
				"id": 64497,
				"name": "It\'s all too much / Never say die",
				"artist": {
					"id": 0,
					"name": "",
					"picUrl": null,
					"alias": [],
					"albumSize": 0,
					"picId": 0,
					"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
					"img1v1": 0,
					"trans": null
				},
				"publishTime": 1254844800000,
				"size": 4,
				"copyrightId": 0,
				"status": 1,
				"picId": 6025323720440883
			},
			"duration": 261120,
			"copyrightId": 663018,
			"status": 0,
			"alias": [],
			"rtype": 0,
			"ftype": 0,
			"mvid": 0,
			"fee": 0,
			"rUrl": null
		},
		{
			"id": 507933243,
			"name": "Again",
			"artists": [{
				"id": 12175271,
				"name": "Noah Cyrus",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			},
			{
				"id": 12107961,
				"name": "XXXTENTACION",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			}],
			"album": {
				"id": 36320081,
				"name": "Again",
				"artist": {
					"id": 0,
					"name": "",
					"picUrl": null,
					"alias": [],
					"albumSize": 0,
					"picId": 0,
					"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
					"img1v1": 0,
					"trans": null
				},
				"publishTime": 1506009600007,
				"size": 1,
				"copyrightId": 7001,
				"status": 3,
				"picId": 18856624416453610
			},
			"duration": 194011,
			"copyrightId": 7001,
			"status": 0,
			"alias": [],
			"rtype": 0,
			"ftype": 0,
			"mvid": 5670036,
			"fee": 8,
			"rUrl": null
		},
		{
			"id": 28272045,
			"name": "again",
			"artists": [{
				"id": 18168,
				"name": "YUI",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			}],
			"album": {
				"id": 492527,
				"name": "\xe9\x8b\xbc\xe3\x81\xae\xe9\x8c\xac\xe9\x87\x91\xe8\xa1\x93\xe5\xb8\xab THE BEST",
				"artist": {
					"id": 0,
					"name": "",
					"picUrl": null,
					"alias": [],
					"albumSize": 0,
					"picId": 0,
					"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
					"img1v1": 0,
					"trans": null
				},
				"publishTime": 1330444800000,
				"size": 24,
				"copyrightId": 0,
				"status": 3,
				"picId": 5890083790153984,
				"alia": ["\xe9\x92\xa2\xe4\xb9\x8b\xe7\x82\xbc\xe9\x87\x91\xe6\x9c\xaf\xe5\xb8\x88\xe4\xb8\xbb\xe9\xa2\x98\xe6\x9b\xb2\xe9\x9b\x86"]
			},
			"duration": 256470,
			"copyrightId": 663018,
			"status": 0,
			"alias": [],
			"rtype": 0,
			"ftype": 0,
			"mvid": 0,
			"fee": 0,
			"rUrl": null
		},
		{
			"id": 406086474,
			"name": "Again (Slinz Remix)",
			"artists": [{
				"id": 1132878,
				"name": "Slinz",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			},
			{
				"id": 76066,
				"name": "Secrets in Stereo",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			}],
			"album": {
				"id": 34526854,
				"name": "Again (Slinz Remix)",
				"artist": {
					"id": 0,
					"name": "",
					"picUrl": null,
					"alias": [],
					"albumSize": 0,
					"picId": 0,
					"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
					"img1v1": 0,
					"trans": null
				},
				"publishTime": 1454083200007,
				"size": 1,
				"copyrightId": 0,
				"status": 0,
				"picId": 1426066583409882
			},
			"duration": 228778,
			"copyrightId": 0,
			"status": 0,
			"alias": [],
			"rtype": 0,
			"ftype": 0,
			"mvid": 0,
			"fee": 0,
			"rUrl": null
		},
		{
			"id": 443875173,
			"name": "again",
			"artists": [{
				"id": 18961,
				"name": "ClariS",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			}],
			"album": {
				"id": 35022075,
				"name": "again",
				"artist": {
					"id": 0,
					"name": "",
					"picUrl": null,
					"alias": [],
					"albumSize": 0,
					"picId": 0,
					"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
					"img1v1": 0,
					"trans": null
				},
				"publishTime": 1480435200007,
				"size": 4,
				"copyrightId": 0,
				"status": 1,
				"picId": 18679603046316281
			},
			"duration": 256705,
			"copyrightId": 663018,
			"status": 0,
			"alias": ["\xe6\xb8\xb8\xe6\x88\x8f\xe3\x80\x8a\xe7\xa7\x8b\xe5\x8f\xb6\xe5\x8e\x9f\xe4\xb9\x8b\xe5\x87\xbb\xe3\x80\x8b\xe4\xb8\xbb\xe9\xa2\x98\xe6\x9b\xb2 / PS4&PS Vita\xe3\x82\xb2\xe3\x83\xbc\xe3\x83\xa0\xe3\x80\x8cAKIBA\'S BEAT\xe3\x80\x8d\xe4\xb8\xbb\xe9\xa1\x8c\xe6\xad\x8c"],
			"rtype": 0,
			"ftype": 0,
			"mvid": 5395037,
			"fee": 0,
			"rUrl": null,
			"alias": ["\xe6\xb8\xb8\xe6\x88\x8f\xe3\x80\x8a\xe7\xa7\x8b\xe5\x8f\xb6\xe5\x8e\x9f\xe4\xb9\x8b\xe5\x87\xbb\xe3\x80\x8b\xe4\xb8\xbb\xe9\xa2\x98\xe6\x9b\xb2 / PS4&PS Vita\xe3\x82\xb2\xe3\x83\xbc\xe3\x83\xa0\xe3\x80\x8cAKIBA\'S BEAT\xe3\x80\x8d\xe4\xb8\xbb\xe9\xa1\x8c\xe6\xad\x8c"]
		},
		{
			"id": 26137307,
			"name": "again (TV Size)",
			"artists": [{
				"id": 21138,
				"name": "V.A.",
				"picUrl": null,
				"alias": [],
				"albumSize": 0,
				"picId": 0,
				"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
				"img1v1": 0,
				"trans": null
			}],
			"album": {
				"id": 2394630,
				"name": "FULLMETAL ALCHEMIST Original Soundtrack 1",
				"artist": {
					"id": 0,
					"name": "",
					"picUrl": null,
					"alias": [],
					"albumSize": 0,
					"picId": 0,
					"img1v1Url": "http://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
					"img1v1": 0,
					"trans": null
				},
				"publishTime": 1255449600007,
				"size": 31,
				"copyrightId": 0,
				"status": 1,
				"picId": 2319969534632721
			},
			"duration": 99919,
			"copyrightId": 663018,
			"status": 0,
			"alias": [],
			"rtype": 0,
			"ftype": 0,
			"mvid": 0,
			"fee": 0,
			"rUrl": null
		}],
		"songCount": 600
	},
	"code": 200
}'