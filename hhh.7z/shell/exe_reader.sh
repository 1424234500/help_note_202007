#! /bin/bash
read -p "enter number:" no
read -p "enter name:" name
echo you have entered $no, $name



